import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Home from './components/home';

import Navbar from './components/Navbar';
import PatientHome from './components/PatientHome';
import AppointmentDetails from './components/AppointmentDetails';
import MedicationReport from './components/MedicationReport';
import TestReportUpload from './components/TestReportUpload';

const App = () => {
  return (
    <Router>
       <Navbar />
      <Routes>
        <Route exact path="/" element={<Home/>} />
        <Route path="/patient-home" element={<PatientHome />} />
        <Route path="/appointment-details" element={<AppointmentDetails />} />
        <Route path="/medication-report" element={<MedicationReport/>} />
        <Route path="/test-report-upload" element={<TestReportUpload/>} />
      </Routes>
    </Router>
  );
};

export default App;
