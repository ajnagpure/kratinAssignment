import React from 'react';
import { Link } from 'react-router-dom';

const MedicationReport = () => {
  return (
    <div  className='container'>
      <h1>Medication Report</h1>
      {/* Doctor's medication report: prescriptions, diet, things to avoid, tests, other details */}
      <br/>

      <h7>Medical Report not yet available.</h7>
      <Link to="/test-report-upload" className="btn btn-primary">Next</Link>
    </div>
  );
};

export default MedicationReport;
