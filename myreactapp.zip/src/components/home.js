import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
  <div className='container'>
      <h1>Welcome to Elderly Care</h1>
      <div>
        <h3>Login for Doctor</h3>
        {/* Doctor login form */}
        <Link to="/patient-home" className="btn btn-primary">Login as Doctor</Link>
      </div>
      <div>
        <h3>Login for Patient</h3>
        {/* Patient login form */}
        <Link to="/patient-home" className="btn btn-primary">Login as Patient</Link>
      </div>
    </div>
  );
};

export default Home;
