import React, { useState }  from 'react';
import { Link, useLocation } from 'react-router-dom';

// const AppointmentDetails = () => {
//   const location = useLocation();
//   const searchParams = new URLSearchParams(location.search);
//   const selectedDoctor = searchParams.get('doctor');

//   return (
//     <div className='container'>
//       <h1>Appointment Details</h1>
//       <p>Selected Doctor: {selectedDoctor}</p>
//       {/* Add appointment form and other details here */}
//       <Link to="/medication-report" className="btn btn-primary">Next</Link>
//     </div>
//   );
// };

// export default AppointmentDetails;

const AppointmentDetails = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const selectedDoctor = searchParams.get('doctor');

  const [date, setDate] = useState('');
  const [time, setTime] = useState('');

  const handleDateChange = (event) => {
    setDate(event.target.value);
  };

  const handleTimeChange = (event) => {
    setTime(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    // Logic to handle the appointment submission
    console.log(`Booked appointment with ${selectedDoctor} on ${date} at ${time}`);
  };

  return (
    <div className='container'>
      <h1>Appointment Details</h1>
      <p>Selected Doctor: {selectedDoctor}</p>

      <form onSubmit={handleSubmit}>
        <div>
          <label>Date:</label>
          <input type="date" value={date} onChange={handleDateChange} required />
        </div>
        <br/>
        <div>
          <label>Time:</label>
          <input type="time" value={time} onChange={handleTimeChange} required />
        </div>
<br/>
<Link to="/medication-report" className="btn btn-primary">Book Appointment</Link>
      </form>
    </div>
  );
};

export default AppointmentDetails;