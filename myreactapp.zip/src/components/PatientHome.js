import React, { useState } from "react";
import { Link } from "react-router-dom";
import Dropdown from "react-bootstrap/Dropdown";


const PatientHome = () => {
  const [selectedDisease, setSelectedDisease] = useState('');
  const [doctorDetails, setDoctorDetails] = useState([]);

  const diseases = [
    { name: 'Cancer', doctors: ['Terry Fox', 'Lolla Grande'] },
    { name: 'TB', doctors: ['Andrew Tate', 'Scott Lynch'] },
    { name: 'Typhoid', doctors: ['Bella Poach', 'Meghan Strew'] },
    { name: 'Alzeimar', doctors: ['Willy Wonka'] },
    { name: 'Diabetes', doctors: ['Stuart Broad', 'Mitchel Starc'] },
  ];

  const handleDiseaseChange = (event) => {
    const selectedDisease = event.target.value;
    setSelectedDisease(selectedDisease);

    // Find the selected disease in the diseases array
    const disease = diseases.find((disease) => disease.name === selectedDisease);

    if (disease) {
      // Set the doctor details based on the selected disease
      setDoctorDetails(disease.doctors);
    } else {
      // If the selected disease is not found, reset the doctor details
      setDoctorDetails([]);
    }
  };

  return (
    <div className="container">
      <h1>Welcome, Patient Name!</h1>
      <div>
        <h3>Search for Diseases</h3>
        <select
          value={selectedDisease}
          onChange={handleDiseaseChange}
          className="form-control"
        >
          <option value="">Select Disease</option>
          {diseases.map((disease) => (
            <option key={disease.name} value={disease.name}>
              {disease.name}
            </option>
          ))}
        </select>
      </div>
      <div>
        {doctorDetails.length > 0 ? (
          <div>
            <h3>Specialist Doctors</h3>
            <ul>
              {doctorDetails.map((doctor, index) => (
                <li key={index}>
                  {doctor}{' '}
                  <Link
                    className="btn btn-primary"
                    to={`/appointment-details?doctor=${encodeURIComponent(doctor)}`}
                  >
                    Book Appointment
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <p>No specialist doctors available for the selected disease.</p>
        )}
      </div>
    </div>
  );
};

export default PatientHome;