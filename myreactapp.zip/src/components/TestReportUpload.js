import React from 'react';
import { Link } from 'react-router-dom';

const TestReportUpload = () => {
  return (
    <div  className='container'>
      <h1>Test Reports Upload</h1>
      {/* Form to upload test reports */}
      <Link to="/patient-home" className="btn btn-primary">Finish</Link>
    </div>
  );
};

export default TestReportUpload;
