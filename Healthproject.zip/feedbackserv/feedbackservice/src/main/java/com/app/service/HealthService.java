package com.app.service;

import com.app.pojos.MedicationList;
import com.app.pojos.NutriciousDiet;
import com.app.pojos.ThingsToAvoid;

public interface HealthService {

	NutriciousDiet getNutriciousDietById(Long PatientId);

	ThingsToAvoid getThingsToAvoidById(Long avoidId);

	MedicationList getMedicationById(Long medicationId);

}
