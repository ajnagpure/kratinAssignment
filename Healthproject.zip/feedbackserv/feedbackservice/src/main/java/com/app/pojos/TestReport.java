package com.app.pojos;
	
	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.JoinColumn;
	import javax.persistence.ManyToOne;
	import javax.persistence.OneToOne;
	import javax.persistence.Table;

	import lombok.Getter;
	import lombok.NoArgsConstructor;
	import lombok.Setter;
	import lombok.ToString;

	@Getter
	@Setter
	@NoArgsConstructor
	@ToString
	@Entity
	@Table(name = "testreport")
	public class TestReport {
		@javax.persistence.Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "testreport_id")
		private Long Id;
		
		@OneToOne
		@JoinColumn(name = "DoctorDetails")
		private DoctorDetails doctorDetails;
		
		@OneToOne
		@JoinColumn(name = "PatientDetails" )
		private PatientDetails patientDetails;
		
		@Column(name= "report", nullable = true, length = 70)
		private String testReport;
}


