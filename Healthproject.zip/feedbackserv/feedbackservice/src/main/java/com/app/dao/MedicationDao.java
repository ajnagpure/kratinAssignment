package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.MedicationList;


public interface MedicationDao extends JpaRepository<MedicationList, Long> {
	Optional<MedicationList> findById(Long PatientId);
	
}
