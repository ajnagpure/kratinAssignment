package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.ThingsToAvoid;



public interface ToAvoidDao extends JpaRepository<ThingsToAvoid, Long>{
	Optional<ThingsToAvoid> findById(Long PatientId);

}
