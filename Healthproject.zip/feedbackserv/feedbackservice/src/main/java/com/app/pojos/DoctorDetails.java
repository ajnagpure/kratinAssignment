package com.app.pojos;


	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Table;

	import lombok.Getter;
	import lombok.NoArgsConstructor;
	import lombok.Setter;
	import lombok.ToString;

	@Getter
	@Setter
	@NoArgsConstructor
	@ToString
	@Entity
	@Table(name = "doctor")
	public class DoctorDetails {
		@javax.persistence.Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "doctor_id")
		private Long Id;
		
		@Column(name = "doctor_name", nullable = true, length = 30 )
		private String Name;
		@Column(name = "doctor_address", nullable = true, length = 40 )
		private String Address;
		
		@Column(name = "doctor_qualification", nullable = true, length = 50)
		private String Qualification;
		
		@Column(name= "doctor_expr", nullable = true, length = 60)
		private String Experience;
}
