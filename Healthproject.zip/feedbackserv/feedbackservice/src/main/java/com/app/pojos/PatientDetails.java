package com.app.pojos;


	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

	import lombok.Getter;
	import lombok.NoArgsConstructor;
	import lombok.Setter;
	import lombok.ToString;

	@Getter
	@Setter
	@NoArgsConstructor
	@ToString
	@Entity
	@Table(name = "patient")
	public class PatientDetails {
		@javax.persistence.Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "patient_id")
		private Long id;
		
		@Column(name = "patient_name", nullable = true, length = 30 )
		private String Name;
		@Column(name = "patient_address", nullable = true, length = 40 )
		private String Address;
		
		@Column(name = "patient_age", nullable = true)
		private Long Age;
		
		@OneToOne
		@JoinColumn(name = "NutriciousDiet" )
		private NutriciousDiet nutridiet;
		
		@OneToOne
		@JoinColumn(name = "ThingsToAvoid" )
		private ThingsToAvoid thingsToAvoid;
		
		@OneToOne
		@JoinColumn(name = "MedicationList" )
		private MedicationList medicationList;
}
