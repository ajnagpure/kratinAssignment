package com.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.app.dao.MedicationDao;
//import com.app.dao.HealthDao;
import com.app.dao.NutriciousDietDao;
import com.app.dao.ToAvoidDao;

import com.app.pojos.MedicationList;
import com.app.pojos.NutriciousDiet;
import com.app.pojos.ThingsToAvoid;

public class HealthServiceImpl implements HealthService{
	
	@Autowired
	NutriciousDietDao health;
	
	@Autowired
	ToAvoidDao avoid;
	
	@Autowired
	MedicationDao med;

	@Override
	public NutriciousDiet getNutriciousDietById(Long PatientId) {
		
			System.out.println("in service");
			Optional<NutriciousDiet> persistedFeedback = health.findById(PatientId);
			NutriciousDiet fb = persistedFeedback.orElse(null);
//			System.out.println(persistedFeedback.getComment());
			return fb;
	}

	@Override
	public ThingsToAvoid getThingsToAvoidById(Long avoidId) {
		System.out.println("in service");
		Optional<ThingsToAvoid> persistedFeedback = avoid.findById(avoidId);
		ThingsToAvoid fb = persistedFeedback.orElse(null);
//		System.out.println(persistedFeedback.getComment());
		return fb;
	
	}

	@Override
	public MedicationList getMedicationById(Long medicationId) {
		System.out.println("in service");
		Optional<MedicationList> persistedFeedback = med.findById(medicationId);
		MedicationList fb = persistedFeedback.orElse(null);
//		System.out.println(persistedFeedback.getComment());
		return fb;
	}

}
