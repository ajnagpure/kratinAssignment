package com.app.controller;

	import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//	import com.app.pojos.Feedback;
//	import com.app.pojos.FeedbackCriteria;
import com.app.pojos.MedicationList;
import com.app.pojos.NutriciousDiet;
//import com.app.pojos.StudentFeedbackRatings;
import com.app.pojos.ThingsToAvoid;
//import com.app.service.FeedbackService;
import com.app.service.HealthService;
import com.app.utils.Message;

	@CrossOrigin
	@RestController
	@RequestMapping("/health")
	public class HealthController {
		@Autowired
		HealthService health;
		

//		@CrossOrigin
//		@PostMapping("/add")
//		public ResponseEntity<Object> addNewFeedback(@RequestBody Feedback feedback){
//			
//			try {
//				fbService.addNewFeedback(feedback);
//				return Message.getSuccessMessage("Feedback added successfully", HttpStatus.OK);
//			}catch(Exception e) {
//				return Message.getErrorMessage(e, HttpStatus.INTERNAL_SERVER_ERROR);
//			}
//		}
		
//		
//		@GetMapping("/{FeedbackId}")
//		public ResponseEntity<Object> getFeedbackById(@PathVariable Long FeedbackId){
//			try {
//				Feedback found = fbService.getFeedbackById(FeedbackId);
//				return Message.getSuccessMessage(found, HttpStatus.OK);
//			}catch(Exception e) {
//				return Message.getErrorMessage(e, HttpStatus.INTERNAL_SERVER_ERROR);
//			}
//			
//		}
		
		@GetMapping("/{PatientId}")
		public ResponseEntity<Object> getNutriciousDietById(@PathVariable Long PatientId)
		{
			try {
				NutriciousDiet ndiet = health.getNutriciousDietById(PatientId);
				return Message.getSuccessMessage(ndiet, HttpStatus.OK);
			}catch(Exception e) {
			return Message.getErrorMessage(e, HttpStatus.INTERNAL_SERVER_ERROR) ;
			}
		}
		
		@GetMapping("/{AvoidId}")
		public ResponseEntity<Object> getThingsToAvoidById(@PathVariable Long AvoidId)
		{
			try {
				ThingsToAvoid avoid = health.getThingsToAvoidById(AvoidId);
				return Message.getSuccessMessage(avoid, HttpStatus.OK);
			}catch(Exception e) {
			return Message.getErrorMessage(e, HttpStatus.INTERNAL_SERVER_ERROR) ;
			}
		}
		
		@GetMapping("/{medicationId}")
		public ResponseEntity<Object> getMedicationById(@PathVariable Long medicationId)
		{
			try {
				MedicationList med = health.getMedicationById(medicationId);
				return Message.getSuccessMessage(med, HttpStatus.OK);
			}catch(Exception e) {
			return Message.getErrorMessage(e, HttpStatus.INTERNAL_SERVER_ERROR) ;
			}
		}
		
		//adityaN
//		@GetMapping("/module/{moduleId}")
//		public List<Feedback> getAllFeedbackByModuleId(@PathVariable Long moduleId){
//			System.out.println("run krke dekh rha");
//			//System.out.println(moduleId);
//			List<Feedback> feedback = fbService.getAllFeedbackByModuleId(moduleId);
//			return feedback;
//		}
		
//		@PostMapping("/addRatings")
//		public ResponseEntity<Object> addRatings(@RequestBody ArrayList<StudentFeedbackRatings> feedbackData){
//			try {			
//				 fbService.insertRatings(feedbackData);
//				return  Message.getSuccessMessage("Ratings Added successfully", HttpStatus.OK);
//			}catch(Exception e) {
//				return Message.getErrorMessage(e, HttpStatus.INTERNAL_SERVER_ERROR);
//			}
//		}
//		@GetMapping("/allcriteria")
//		public List<FeedbackCriteria> getAllcriteria()
//		{
//			List<FeedbackCriteria> criteria = fbService.getAllFeedbackCriteria();
//			return criteria;
//		}

}
