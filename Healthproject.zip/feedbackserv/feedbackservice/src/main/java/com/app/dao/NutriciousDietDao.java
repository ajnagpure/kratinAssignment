package com.app.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.NutriciousDiet;

public interface NutriciousDietDao extends JpaRepository<NutriciousDiet, Long> {
	
	Optional<NutriciousDiet> findById(Long PatientId);
}
